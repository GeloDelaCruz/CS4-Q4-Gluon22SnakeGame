/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snakegame;

import java.util.ArrayList;
import java.util.Random;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 *
 * @author YoungSleepyBoi
 */
public class SnakeGame extends Application {
    
    static int speed = 5;
    static int foodcolor = 0;
    static int width = 20;
    static int height = 20;
    static int foodXCoord = 0;
    static int foodYCoord = 0;
    static int snakeCornerSize = 25;
    static ArrayList<Corner> snakeCorner = new ArrayList<>();
    static Dir direction = Dir.up;
    static boolean gameOver = false;
    static Random rand = new Random();
    
    public static class Corner{
        int a, b;
        
        public Corner(int a, int b){
            this.a = a;
            this.b = b;
        }
    }
    
    public enum Dir{
        up, down, left, right
    }
    
    @Override
    public void start(Stage stage){
        try{
            newFoodItem();
            
            VBox root = new VBox();
            Canvas canvas = new Canvas(width*snakeCornerSize, height*snakeCornerSize);
            GraphicsContext game = canvas.getGraphicsContext2D();
            root.getChildren().add(canvas);

            new AnimationTimer(){
                long lastTick = 0;

                public void handle(long now){
                    if(lastTick==0){
                        lastTick = now;
                        tick(game);
                        return;
                    }

                    if (now - lastTick > 1000000000/speed){
                        lastTick = now;
                        tick(game);
                    }
                }
            }.start();

            Scene scene = new Scene(root, width*snakeCornerSize, height*snakeCornerSize);
            
            scene.addEventFilter(KeyEvent.KEY_PRESSED, key ->{
                if(key.getCode()==KeyCode.W){
                    direction = Dir.up;
                }
                else if(key.getCode()==KeyCode.A){
                    direction = Dir.left;
                }
                else if(key.getCode()==KeyCode.S){
                    direction = Dir.down;
                }
                else if(key.getCode()==KeyCode.D){
                    direction = Dir.right;
                }
            });
            
            snakeCorner.add(new Corner(width/2, height/2));
            snakeCorner.add(new Corner(width/2, height/2));
            snakeCorner.add(new Corner(width/2, height/2));

            stage.setTitle("Snake Game Prototype");
            stage.setScene(scene);
            stage.show();
        }
        catch (Exception exception){
            exception.printStackTrace();
        }
    }
    public static void tick(GraphicsContext graphconx){
        if (gameOver){
            graphconx.setFill(Color.RED);
            graphconx.setFont(new Font("", 50));
            graphconx.fillText("GAME OVER", 100, 250);
            return;
        }
        
        for (int i = snakeCorner.size()-1;i>=1;i--){
            snakeCorner.get(i).a = snakeCorner.get(i-1).a;
            snakeCorner.get(i).b = snakeCorner.get(i-1).b;
        }
        
        switch (direction){
            case up:
                snakeCorner.get(0).b--;
                if(snakeCorner.get(0).b<0){
                    gameOver = true;
                }
                break;
            case down:
                snakeCorner.get(0).b++;
                if(snakeCorner.get(0).b>height){
                    gameOver = true;
                }
                break;
            case left:
                snakeCorner.get(0).a--;
                if(snakeCorner.get(0).a<0){
                    gameOver = true;
                }
                break;
            case right:
                snakeCorner.get(0).a++;
                if(snakeCorner.get(0).a>width){
                    gameOver = true;
                }
                break;
        }
        
        if(foodXCoord==snakeCorner.get(0).a && foodYCoord==snakeCorner.get(0).b){
            snakeCorner.add(new Corner(-1,-1));
            newFoodItem();
        }
        
        for (int i=1;i<snakeCorner.size();i++){
            if(snakeCorner.get(0).a == snakeCorner.get(i).a && (snakeCorner.get(0).b == snakeCorner.get(i).b)){
                gameOver = true;
            }
        }
        
        graphconx.setFill(Color.BLACK);
        graphconx.fillRect(0,0, width*snakeCornerSize, height*snakeCornerSize);
        
        graphconx.setFill(Color.WHITE);
        graphconx.setFont(new Font ("", 30));
        graphconx.fillText("Score: ", +(speed-6), 10, 30);
        
        Color color = Color.WHITE;
        
        switch(foodcolor){
            case 0: color = Color.PURPLE;
            break;
            case 1: color = Color.YELLOW;
            break;
            case 2: color = Color.GREEN;
            break;
            case 3: color = Color.CYAN;
            break;
            case 4: color = Color.DARKSLATEBLUE;
            break;
        }
        
        graphconx.setFill(color);
        graphconx.fillOval(foodXCoord*snakeCornerSize, foodYCoord*snakeCornerSize, snakeCornerSize, snakeCornerSize);
        
        for(Corner corner:snakeCorner){
            graphconx.setFill(Color.PINK);
            graphconx.fillRect(corner.a*snakeCornerSize, corner.b*snakeCornerSize, snakeCornerSize-1, snakeCornerSize-1);
            
            graphconx.setFill(Color.MAGENTA);
            graphconx.fillRect(corner.a*snakeCornerSize, corner.b*snakeCornerSize, snakeCornerSize-2, snakeCornerSize-2);
        }
    }
    
    public static void newFoodItem(){
        start:while(true){
            foodXCoord = rand.nextInt(width);
            foodYCoord = rand.nextInt(height);
            
            for(Corner corner:snakeCorner){
                if(corner.a==foodXCoord && corner.b==foodYCoord){
                    continue start;
                }
            }
            foodcolor = rand.nextInt(5);
            speed++;
            break;
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
